# Scoped SIL readiness

Gate: **INCOMPLETE**

Required scenario coverage: 0/23 defined cells. Missing: test_HTTP_validation_and_idempotency_scope, test_HTTP_walking_constraint, test_T01_full_ride, test_T02_duplicate_request, test_T03_assignment_concurrency, test_T04_cancel_approaching, test_T05_stale_assignment, test_T06_duplicate_ack_loss, test_T07_reordered_events, test_T08_partition, test_T09_backend_restart, test_T10_agent_restart_tombstone, test_T11_pickup_change, test_T12_duplicate_completion, test_T13_stale_operator, test_T14_old_lease, test_T15_cancel_after_boarding, test_T15_cancel_boarding_race, test_T16_simulator_exit, test_UI_cancel_pending_confirmed, test_UI_normal, test_UI_pickup_revision_operator, test_UI_stale.

All attempts in the selected group are counted. A subsequent pass does not erase an earlier failure. Seeded defective runs are listed separately.

| Outcome | Count |
|---|---:|
| pass | 0 |
| product_failure | 0 |
| infrastructure_error | 0 |
| skipped | 0 |
| not_run | 0 |

| Scenario / requirements | Outcome(s) | Evidence |
|---|---|---|
| test_T01_full_ride (R04, R05, R06, R14) | not_run | — |
| test_T02_duplicate_request (R01, R02) | not_run | — |
| test_T03_assignment_concurrency (R02) | not_run | — |
| test_T04_cancel_approaching (R11) | not_run | — |
| test_T05_stale_assignment (R03, R11) | not_run | — |
| test_T06_duplicate_ack_loss (R07) | not_run | — |
| test_T07_reordered_events (R04) | not_run | — |
| test_T08_partition (R09, R12) | not_run | — |
| test_T09_backend_restart (R08) | not_run | — |
| test_T10_agent_restart_tombstone (R03, R07) | not_run | — |
| test_T11_pickup_change (R05, R10) | not_run | — |
| test_T12_duplicate_completion (R06) | not_run | — |
| test_T13_stale_operator (R13) | not_run | — |
| test_T14_old_lease (R03, R12) | not_run | — |
| test_T15_cancel_boarding_race (R04, R05, R11) | not_run | — |
| test_T15_cancel_after_boarding (R04, R05, R11) | not_run | — |
| test_T16_simulator_exit (R14) | not_run | — |
| test_UI_normal (R04, R09) | not_run | — |
| test_UI_cancel_pending_confirmed (R11) | not_run | — |
| test_UI_stale (R09) | not_run | — |
| test_UI_pickup_revision_operator (R10, R13) | not_run | — |
| test_HTTP_validation_and_idempotency_scope (R01) | not_run | — |
| test_HTTP_walking_constraint (R10) | not_run | — |

## Observed metrics

| Metric / clock | Samples | Range |
|---|---:|---|
| ack_delay_sim_seconds | 0 | not measured |
| cancel_convergence_sim_seconds | 0 | not measured |
| reconciliation_sim_seconds | 0 | not measured |
| ui_convergence_wall_seconds | 0 | not measured |
| api_wall_seconds | 0 | not measured |
| duplicate_completion_effects | 0 | not measured |
| ride_completion_sim_seconds | 0 | not measured |

Failed scenario assertions: 0. This is not an exhaustive count of all possible invariant violations.
Artifact gaps: 0.

## Build and scope


## Seeded defect profiles

- seeded-defect-v1: defective, product_failure; excluded from corrected release coverage.

## Limitations

One synthetic vehicle, one mission, one seed in the acceptance batch. Application-message faults, logical passengers/doors, annotated walking access, and modeled curb occupancy. No perception, controller, physical curb, cellular packet, vehicle-safety or production HA validation.
Agent restarts are tested at completed step checkpoints; SQLite and SUMO cannot commit atomically. Arbitrary mid-step crashes are outside the demonstrated recovery scope. GUI mode is optional and is not a headless acceptance result. CI configuration is supplied but remote CI was not executed locally.
UI timings measure observation-to-browser assertion wall time, not network latency alone. Raw ranges are used; no small-sample p95 claims. Selected reruns demonstrate only the selected scenario and seed.
